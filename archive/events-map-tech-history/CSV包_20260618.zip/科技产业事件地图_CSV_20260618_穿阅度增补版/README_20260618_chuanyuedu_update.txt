2026-2027科技产业事件地图数据库｜20260618穿阅度增补版

本版基于 `20260618_AI软件服务补录版` 增补。
本次更新原则：不把穿阅度材料中的交易指令、目标市值、仓位、具体订单传闻写入事实事件；多数进入 signals_early / corrections。

新增/强化：
1. events 新增 POWER-GT-2026-001：燃气轮机核心部件长协强化AIDC海外缺电链验证。
2. events 新增 AM-APPLE-2026-001：Apple 3D打印钛金属在消费电子中的产业化验证。
3. mapping 新增：燃气轮机整机/EPC、涡轮叶片/环件/高温合金、消费电子3D打印、功率器件涨价与AI电源敞口。
4. forward 新增：国产AI芯片订单与涨价验证、燃机长协验证、Apple 3D打印扩展、功率器件二轮涨价。
5. signals_early 新增：国产算力二线卡、国产GPU涨价、燃机长协、算力租赁渠道回暖、Apple 3D打印、功率器件二轮涨价、科技抽水交易结构。
6. corrections 新增：国产算力订单传闻、算力租赁渠道传闻、Apple 3D打印外推、科技拥挤交易风险。

读取规则：
- 外部AI/研究助手优先读取 events，再用 event_id 关联 mapping / forward / corrections / signals_early。
- signals_early 只表示早期线索，不等同于事实订单或推荐股票。
- 代表公司/公司类型只用于产业链定位，不构成买卖建议。
- 高拥挤方向提高验证门槛：看订单、长协、涨价函、出货、毛利率、财报，而不是只看小作文热度。

文件清单：
- events_20260618_chuanyuedu_update.csv
- mapping_20260618_chuanyuedu_update.csv
- forward_20260618_chuanyuedu_update.csv
- reviews_20260618_chuanyuedu_update.csv
- corrections_20260618_chuanyuedu_update.csv
- sources_20260618_chuanyuedu_update.csv
- weekly_20260618_chuanyuedu_update.csv
- signals_early_20260618_chuanyuedu_update.csv
- README_20260618_chuanyuedu_update.txt
